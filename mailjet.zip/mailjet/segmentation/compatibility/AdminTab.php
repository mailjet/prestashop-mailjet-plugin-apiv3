<?php

class AdminTab extends AdminTabCore
{
	public static $currentIndex;
}