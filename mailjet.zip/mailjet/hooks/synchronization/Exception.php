<?php 

namespace Hooks\Synchronization;


/**
 * 
 * @author atanas
 *
 */
class Exception extends \Exception
{

}


?>