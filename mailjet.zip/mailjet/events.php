<?php

// if ($_SERVER['PHP_AUTH_USER'] != "mailjet" || $_SERVER['PHP_AUTH_PW'] != "MJPSMOD9463PWD")
// 	die("ERROR, no access granted...");

include_once(realpath(dirname(__FILE__).'/../../').'/config/config.inc.php');
include_once(realpath(dirname(__FILE__)).'/classes/MailJetLog.php');
include_once(realpath(dirname(__FILE__)).'/classes/MailJetTranslate.php');
include_once(realpath(dirname(__FILE__)).'/classes/MailJetEvents.php');
include_once(realpath(dirname(__FILE__)).'/hooks/Events.php');
include_once(_PS_ROOT_DIR_.'/init.php');
require_once(dirname(__FILE__).'/mailjet.php');

$mj = new Mailjet();

if ($mj->getEventsHash() !== $_GET['h']) {
	header('HTTP/1.1 401 Unauthorized');
	return;
}

# Catch Event
$post = trim(Tools::file_get_contents('php://input'));
//mail("astoyanov@mailjet.com", "", print_r($post, true));

# No Event sent
if(empty($post)) {
	header('HTTP/1.1 421 No event');
	// => do action
	return;
}

# Decode Trigger Informations
$t = Tools::jsonDecode($post, true);

# No Informations sent with the Event
if(!is_array($t) || !isset($t['event'])) {
	header('HTTP/1.1 422 Not ok');
	// => do action
	return;
}


$events = new MailJetEvents($t['event'], $t);

/* 
 *	Event handler 
 *	- please check https://www.mailjet.com/docs/event_tracking for further informations.
 */

switch($t['event']) {
	case 'open':
		// => do action
		// If an error occurs, tell Mailjet to retry later: header('HTTP/1.1 400 Error');
		// If it works, tell Mailjet it's OK
		header('HTTP/1.1 200 Ok');
		break;
	case 'click':
		// => do action
		break;
	
	case 'bounce':
		// => do action
		$events->add();
		break;

	case 'spam':
		// => do action
		$events->add();
		break;

	case 'blocked':
		// => do action
		$events->add();
		break;

	case 'unsub':
		// => do action
		$hooksEvents = new \Hooks\Events();
		$hooksEvents->unsubscribe($t);
		break;

	case 'typofix':
		// => do action
		$events->add();
		break;
		
	# No handler
	default:
		header('HTTP/1.1 423 No handler');
		// => do action
		break;
}


?>